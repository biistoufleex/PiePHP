<?php

namespace Core;

class Core 
{

    public function run() {
        echo __CLASS__ . " [OK] " . "\n";
    }
}
