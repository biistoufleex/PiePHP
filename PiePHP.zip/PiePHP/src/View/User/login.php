<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<center>

    <form action="http://localhost/PiePHP/index.php" method="post">
    
        <label for="email">Enter your email: </label>
        <input type="text" name="email" id="email" required>
        

        <label for="password">Enter your password: </label>
        <input type="text" name="password" id="password" required>

        <input type="submit" value="Subscribe!">

    </form>
</center>
</body>
</html>

<!-- http://localhost/PiePHP/src/View/User/login.php -->